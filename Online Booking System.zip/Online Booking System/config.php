<?php
// Define constants for configuration
define('BASE_URL', 'http://localhost/booking-system');
define('ADMIN_EMAIL', 'admin@example.com');
?>